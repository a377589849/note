package com.note.controller;


import java.util.Objects;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.util.HtmlUtils;

import com.note.pojos.User;
import com.note.result.Result;
import com.note.service.UserSevice;

@Controller
public class LoginController {
	
	@Autowired
	UserSevice userSevice;

	@CrossOrigin
	@PostMapping(value = "/api/login")
	@ResponseBody
	public Result login(@RequestBody User requsertUser,HttpSession session) {
		
		String Name=requsertUser.getUsername();
		Name=HtmlUtils.htmlEscape(Name);
		User user=userSevice.get(Name, requsertUser.getPassword());
		if(user!=null) {
			
			return new Result(400);
		}else {
			session.setAttribute("user", user);
			return new Result(200);
		}
	}
}
